from django.contrib import admin
from .models import board

# Register your models here.

admin.site.register(board)